#include<stdio.h>
#include"lib/nexec.h"
#include<sys/types.h>
#include<sys/wait.h>
#include<signal.h>
#include<unistd.h>
#include<string.h>

void gameplayer(pid_t pid,int *p);
int main(void)
{
	printf("hello, world!\n");
	char *d[]={"o","2","line",NULL};
	int fd[3];
	char pwd[64]="./o";
	pid_t pid;
	printf("pid: %d\n",getpid());
	//kill(getpid(),SIGINT);
	pid=nexec(pwd,(char **)d,NULL,NULL,NULL);
	printf("pid: %d\n",pid);
	wait(&pid);
	fd[1]=fd[2]=open("/dev/null",O_WRONLY);
	pid=nexec(pwd,(char **)d,NULL,&fd[1],&fd[2]);
	if(pid>0)
	{
		printf("pid: %d\n",pid);
		sleep(1);
		kill(pid,SIGINT);
	}
	strcpy(pwd,"./game");
	fd[0]=fd[1]=-1;
	pid=nexec(pwd,(char **)d,&fd[0],&fd[1],&fd[2]);
	if(pid>0)
		gameplayer(pid,(int *)fd);
	close(fd[2]);
	printf("exit\n");
	return 0;
}
void gameplayer(pid_t pid,int *p)
{
	fd_set fds;
	int s,maxfd,d,n,i=0,z=10000;
	char buf[64];
	printf("pid: %d\n",pid);
	memset(buf,'\0',64*sizeof(char));
	s=p[0];
	d=p[1];
	printf("%d %d\n",s,d);
	FD_ZERO(&fds);
	FD_SET(d,&fds);
	maxfd=d;
	while(1)
	{
		n=select(maxfd+1,&fds,(fd_set *)NULL,(fd_set *)NULL,(struct timeval *)NULL);
		//if(n==0)continue;//timeout
		if(n<0)break;
		/*
		for(fd=0;fd<=maxfd;fd++)
		{
			if(FD_ISSET(fd,&_fds))
				break;
		}
		
		if(fd==r)
		*/
		n=read(d,buf,64);
		if(n<=0)
			break;
		if(i<z)
		{
			write(s,buf,n);
		}
		else
		{
			if(i==z)
			{
				buf[0]='.';
				write(s,buf,n);
			}
			else
			{
				printf("%s",buf);
			}
		}
	i++;
	}
	close(p[0]);
	close(p[1]);

}
