#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>

void exit_func(void *t){
	int i=*(int *)t;
	sleep(i);
	printf("exit\n");
	exit(0);
}
int main(int argc,char *argv[]){
	printf("hello, world!\n");
	// 展示参数，重复输入内容(exit退出)
	int i=5;
	int n=0;
	char buf[1024];
	pthread_t th;
	if(argc>1){sscanf(argv[1],"%d",&n);}
	if(n<=0)n=i; //超时时间
	printf("sleep: %d\n",n);
	pthread_create(&th,NULL,(void *)exit_func,&n);
	for(i=0;i<argc;i++){
		printf("%s\n",argv[i]);
	}
	while(1){
		scanf("%s",buf);
		if(strcmp(buf,"exit")==0)break;
		printf("%s\n",buf);
	}
	pthread_detach(th);
	printf("exit\n");
	return 0;
}

