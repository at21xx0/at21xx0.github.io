#ifndef _NEXEC_H__
#define _NEXEC_H__
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
pid_t nexec(char *a,char **b,int *i,int *o,int *e);
#endif
