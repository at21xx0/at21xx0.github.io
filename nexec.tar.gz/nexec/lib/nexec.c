#include "nexec.h"
// new_exec

pid_t nexec(char *a,char **b,int *i,int *o,int *e){
// 创建新进程，返回进程pid。r,w,e 替换 0 1 2 描述符
	pid_t pid=0;
	int fd[3][3],*p[3],*pfd;
	int j,t,k;
	p[0]=i;
	p[1]=o;
	p[2]=e;
	fd[0][2]=STDIN_FILENO;
	fd[1][2]=STDOUT_FILENO;
	fd[2][2]=STDERR_FILENO;
	for(j=0,t=2,k=0;j<3;j++)
	{
		if(t==2)
		{
			if(!p[j]||k==2)
			{
			}
			else if(*p[j]>=0)
			{
			}
			else if(pipe(fd[j])<0)
			{
				k=2;
				pid=-1;
			}
			//else printf("new pipe,i: %d\n",i);
			if(k==2)
			{
				p[j]=NULL;
			}
			if(j==2)
			{
				if(pid==0)pid=fork();
				j=t=k=0;
			}
			else continue;
		}
		if(p[j]==NULL)continue;
		pfd=fd[j];
		t=(j!=0)?0:1;
		k=(t!=0)?0:1;
		if(pid<0)
		{
			close(pfd[0]),close(pfd[1]);
		}
		else if(*p[j]>=0)
		{
			if(pid==0)
			{
				dup2(*p[j],pfd[2]);
			}
		}
		else if(pid==0)
		{
			close(pfd[t]),dup2(pfd[k],pfd[2]);
		}
		else
		{
			close(pfd[k]),*p[j]=pfd[t];
		}
	}
	if(pid==0)
	{
		execv(a,b);
		exit(0);
	}
	return pid;
}

