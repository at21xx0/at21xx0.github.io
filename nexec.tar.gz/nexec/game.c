#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
//#include<curses.h>
#include<time.h>

int main()
{
	//printf("hello, world!");
	// 测试输入字符正确率，换为百分数
	char c;
	char a;
	srand((unsigned)time(NULL));
	int s=0,z=0;
	while(1)
	{
		c=rand()%26+'a';
		printf("%c\n",c);
		fflush(stdout);
		while((a=getchar())=='\n');
		if(a<'a'||a>'z')break;
		z++;
		if(a==c)s++;
	}
	printf("achieve: %d/%d\n",s,z);
	if(z!=0)printf("score: %.2f\n",(float)100*s/z);
	return 0;
}
