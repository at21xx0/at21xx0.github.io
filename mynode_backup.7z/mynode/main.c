#include<stdio.h>
#include<pthread.h>
void do_main();
void do_end(void *p)
{
	while(getc(stdin)!='\n');
	kill(getpid(),SIGINT);
	//exit(1);
}
int main(void)
{
	printf("hello, world!\n");
	pthread_t th;
	pthread_create(&th,NULL,(void *)&do_end,NULL);
	do_main();
	pthread_detach(th);
	return 0;
}
