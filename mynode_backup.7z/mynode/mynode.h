#ifndef __MYNODE_H__
#define __MYNODE_H__
//#include <unistd.h>
#include <stdlib.h>

#define MYNODE_VERSION "1.0"
#endif