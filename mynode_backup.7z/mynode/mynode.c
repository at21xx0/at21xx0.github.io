#include "mynode.h"
#include <stdio.h>
//int create

#define mynode_blank 0
#define mynode_str 1
#define mynode_node 2
#define mynode_inner 3
#define mynode_root 4
#define mynode_free_val 8
#define mynode_free_tag 16
#define mynode_copy 4
#define mynode_next 512
#define mynode_pe 1024
//#define mynode_in 1024
#define mynode_type 0
#define mynode_y 1 // yes
#define mynode_n 0 // no
#define mynode_mget_n 64
//struct mynode_info;
struct mynode_t;
struct mynode_m;
/*
struct mynode_o;
//struct mynode_st mynode_static;
struct mynode_o
{
     unsigned int _copy:1;
     unsigned int _free:1;
};
*/
/*
struct mynode_info
{
    unsigned int type:2;
    unsigned int free_val:1;
    unsigned int _root:1;
    unsigned int blank:4;
};
*/
struct mynode_t 
{
    unsigned char info;
    struct mynode_t *next;
    struct mynode_t *parent;
    char *tag;
    void *val; // value
    //void *e; // end
};
struct mynode_m
{
    int size;
    struct mynode_m *next;
};
struct mynode_t *mynode_getroot(struct mynode_t *node);
struct mynode_t *mynode_cd(char *pwd,struct mynode_t *node);
struct mynode_t *mynode_find(char *u,struct mynode_t *node);
struct mynode_t *mynode_rm(struct mynode_t *node);
struct mynode_t *mynode_put(struct mynode_t *base,char *tag,void *val,unsigned int c);
struct mynode_t *mynode_top(struct mynode_t *node);
int mynode_conf(struct mynode_t *node,int type,int val);
struct mynode_t *mynode_cat(struct mynode_t *base,struct mynode_t *node);
//struct mynode_t *mynode_in();
struct mynode_t *mynode_cp();
struct mynode_t *mynode_match(struct mynode_t *node,char *tag,char *inner_tag,char *inner_val);
struct mynode_t *mynode_add(struct mynode_t *a,struct mynode_t *b);
void mynode_free(struct mynode_t *node);
struct mynode_t *mynode_mget(struct mynode_t *node);
struct mynode_t *mynode_getm(struct mynode_t *node);
//int mynode_ls
int mynode_mfree(struct mynode_t *node);
int mynode_tfree(struct mynode_t *node);


void mynode_free(struct mynode_t *node)
{
    if(!node)return;
    if((node->info>>4)%2)free(node->val);
    if((node->info>>5)%2)free(node->tag);
}
struct mynode_t *mynode_getroot(struct mynode_t *node)
{
     while(1)
     {
          if((node->info>>2)%2)return node;
          if(!(node=node->parent))break;
     }
     return NULL;
}
struct mynode_t *mynode_rm(struct mynode_t *node)
{
mynode_free(node);
node->info=mynode_blank;
return NULL;
}
struct mynode_t *mynode_cat(struct mynode_t *base,struct mynode_t *node)
{
     struct mynode_t *n;
     //if(!base||!node)return NULL;
     if(base->info%4!=node->info%4)return NULL;
     n=base->next;
     base->next=node;
     while(node->next)node=node->next;
     node->next=n;
     return node;
}
//struct mynode_t *
struct mynode_t *mynode_add(struct mynode_t *parent,struct mynode_t *node)
{
    parent->val=(void *)node;
    return node;
}
struct mynode_t *mynode_getm(struct mynode_t *node)
{
    node=mynode_getroot(node);
    if(!node)return NULL;
    while(node->next)
    {
        node=node->next;
        if((node->info%4)!=mynode_inner)
            break;
        if(!node->tag)
            return node;
    }
    return NULL;
}
struct mynode_t *mynode_mget(struct mynode_t *node)
{
    struct mynode_m *m;
    int i,n=mynode_mget_n;
mynode_mget_top:
    if(node)
    {
        node=mynode_getm(node);
        if(!node)return NULL;
        m=(struct mynode_m *)node->val;
mynode_mget_loop_a:
        node=(struct mynode_t *)m+1;
        i=0;
        while(i<n)
        {
             if(!node->info%2)
                  return node;
             node++;
             i++;
        }
        if(i==n&&m->next)
        {
            m=m->next;
            goto mynode_mget_loop_a;
        }
        node=(struct mynode_t *)m;
    }
    i=(node)?1:0;
    m=(struct mynode_m *)malloc(sizeof(struct mynode_m)+n*sizeof(struct mynode_t));
    m->size=n;
    m->next=NULL;
    node=(struct mynode_t*)m+1;
    memset(node,'\0',n*sizeof(struct mynode_t));
    if(i)
    {
        ((struct mynode_m *)node)->next=m;
    }
    else
    {
        node->info=mynode_inner|mynode_free_val|mynode_root;
        node->val=m;
        node++;
        node->next=node-1;
        node->info=mynode_root;
    }
    return node;
}
int mynode_mfree(struct mynode_t *node)
{
    struct mynode_m *m;
    node=mynode_getm(node);
    if(!node)return -1;
    m=(struct mynode_m *)node->val;
    if(m&&(node->info>>3)%2)free(m);
    return 0;
}
struct mynode_t *mynode_put(struct mynode_t *base,char *tag,void *val,unsigned int t)
{
    struct mynode_t *node;
    unsigned char info=(char)t;
    if(info%4==mynode_blank)return NULL;
    node=mynode_mget(base);
    if(!node)return NULL;
    node->info|=info;
    node->tag=tag;
    if((t>>8)%2) //mynode_next
    {
        node->parent=base->parent;
        printf("hhhhh\n");
        mynode_cat(base,node);
    }
    else
    {
        node->parent=base;
        if(base)base->val=val;
    }
    return node;
}
struct mynode_t *mynode_find(char *u,struct mynode_t *node);
struct mynode_t *mynode_match(struct mynode_t *node,char *tag,char *inner_tag,char *inner_val)
{
     int a=0,b=0,c=0;
     if(!node)return NULL;
     while(node->next)
     {
         if(node->info%4==mynode_next)continue;
         //if(node->next);
         //留坑
     }
     return NULL;
}
int mynode_conf(struct mynode_t *node,int type,int val)
{
    int *p;
    if(!node)return -1;
    
    return val;
}
//struct mynode_t *mynode_new();


void do_main()
{
printf("Version %s\n",MYNODE_VERSION);
char buf[64]="hell";
char b[64]="CIA";
char *c="mybook";
//struct mynode_t root;



struct mynode_t *root,*n1,*node,*n2;
root=mynode_put(NULL,NULL,buf,mynode_str);
printf("root: %p %u\n",root,root->info);
node=mynode_put(root,"book",NULL,mynode_node);
printf("node: %p\n",node);
n1=mynode_put(node,"char","endl",mynode_str);
n2=mynode_put(n1,"dl","d",mynode_str|mynode_next);
printf("%p %p %p %p\n\n",root,node,n1,n2);
printf("%s %p %p\n",n1->val,n1->val);
mynode_mfree(n1);
//root_node=mynode_new();
//create();
//mynode_t 
}