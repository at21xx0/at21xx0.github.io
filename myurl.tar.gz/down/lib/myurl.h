#ifndef _MYURL_H__
#define _MYURL_H__
#include "openssl/ssl.h"
#include "openssl/err.h"
#include "zlib.h"
struct myurl_d{
SSL_CTX *ctx; /* ctx */
char head_t[4][128];
char *headers[5]; /* 默认请求头 */
};
struct myurl_info{
char *url; /* 链接 */
//char *pwd; /* 路径(忘记有什么用) */
//char *lu;
char *data; /* post data */
size_t post_len; /* post len */
char **headers; /* 请求头 */
char **extra_headers; /* 额外的请求头 */
int bufsize; /* 缓冲区大小 */
int code; /* 返回code */
char **get_headers; /* 获取响应头 例如{"Content-Type:","Date:",NULL}(用malloc()} */
unsigned int follow:1; /* 重定向 */
size_t (*r)(void *,size_t,size_t,void *); /* post (未完成) */
size_t (*h)(void *,size_t,size_t,void *); /* 写 请求头 */
size_t (*w)(void *,size_t,size_t,void *); /* 写 请求体 */
void *rh; /* r 最后一个参数 */
void *hh; /* h 最后一个参数 */
void *wh; /* w 最后一个参数 */
};
struct myurl_h{
int i;
z_stream *z;
char **headers;
char **extra_headers;
unsigned long long l;
unsigned long long l1;
unsigned long long length;
int s;
SSL_CTX *ctx;
SSL *ssl;
char *search_buf;
char *z_mem;
char *buf;
int search_bufsize;
int search_bufsize2;
unsigned int gzip_y:1;
unsigned int chunked_y:1;
unsigned int http_y:1;
unsigned int follow_y:2;
unsigned int only_get_length:1;
unsigned int extra_y:2;
struct myurl_info *info;
};
void myurl_heada(char ***handle,char *s,int mode);
extern int myurl_link(char *u,int *s,SSL **ssl,SSL_CTX **ctx,char *host,char *a);
extern int myurl_st_init(struct myurl_h *h);
extern int myurl_free(struct myurl_h *h);
extern char *myurl_heada_search(char **a,char **b,char *n);
extern ssize_t myurl_write(int s,SSL *ssl,char *buf,size_t i);
extern int myurl_base_search(size_t a,size_t b,size_t bufsize,char *buf,char *y,char *z);
extern int myurl_search(size_t a,size_t b,size_t c,char *d,struct myurl_h *h);
extern size_t myurl_w_void(void *buf,size_t a,size_t b,void *p);
extern void myurl_end(void);
extern int myurl_main(struct myurl_info *info);
extern int myurl_url(char *a);
#endif
