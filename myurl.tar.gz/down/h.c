#include<stdio.h>
#include<stdlib.h>
#include "lib/myurl.h"

//clang -Wall h.c -lcrypto -lssl -lz
//#define h_url "http://127.0.0.1:8080/index.html"
//#define h_url "https://www.baidu.com/index.html"
//#define h_url "https://1978aa52b39f677b58c5c8d8f8ed7312.dlied1.cdntips.net/dlied1.qq.com/qqweb/QQ_1/android_apk/AndroidQQ_8.4.5.4745_537065283.apk"
//#define h_url "https://ma75.gdl.netease.com/Sky_Gold_0.6.2_149571_obt_netease_encrypted_minify.apk"
//#define h_url "http://issuecdn.baidupcs.com/issue/netdisk/apk/BaiduNetdiskSetup_wap_new.apk"
//#define h_url "http://dl.as.61.com/AvatarStar_Setup_1.4.0.65410.exe"
#define h_url "http://libs.baidu.com/jquery/2.1.4/jquery.min.js"
//#define h_url "http://www.baidu.com/index.html"


struct d_info{
char *file;
char *url;
int t;
};
int d(struct d_info *info){
size_t len;
char *b;
len=strlen(info->url)+1;
b=(char *)malloc(len*sizeof(char));
strcpy(b,info->url);
struct myurl_info t;
memset(&t,'\0',sizeof(struct myurl_info));
t.url=b;
/*
t.w=(void *)&fwrite;
t.wh=(void *)fopen("/storage/emulated/0/home/work/down/a.txt","w+");
*/
//t.bufsize=1024;
t.follow=1;
/* post
strcpy(b,"https://www.runoob.com/try/ajax/demo_post2.php");
t.data="fname=Henry&lname=Ford"; */
//strcpy(b,"http://www.baidu.com/index.html");

/*
t.h=(void *)&fwrite;
t.hh=(void *)stdout;
*/
if(info->file){
t.w=(void *)&fwrite;
t.wh=(void *)fopen(info->file,"w+");
}else{
t.w=(void *)&fwrite;
t.wh=(void *)stdout;
}
//myurl_main(&t);
for(int i=0;i<info->t;i++){printf("No.%d\n",i);myurl_main(&t);}
//printf("%s\n",b);
//sleep(1);
free(b);
if(info->file)fclose((FILE *)t.wh);
//sleep(3);
return 0;
}
int main(int argc,char **argv){
printf("hello, world!\n");
struct d_info info;
info.url=(argc>1)?argv[1]:h_url;
if(argc>2){info.t=0;sscanf(argv[2],"%d",&info.t);
if(info.t==0){
info.t=1;
info.file=argv[2];
}
}else info.t=1;
d(&info);
myurl_end();
return 0;
}
