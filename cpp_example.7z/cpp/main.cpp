#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cstdio>
#include<cstring>
using namespace std;

class pz
{
	protected:
		double sx;
		double sy;
		double hx;
		double hy;
		long n;
	public:
		double a,b;
		pz()
		{
			a=b=sx=sy=hx=hy=0;
			n=0;
		}
		void add(double x,double y)
		{
			n++;
			sx+=x;
			sy+=y;
			hx+=x*y;
			hy+=x*x;
		}
		void show()
		{
			double x=sx/n;
			b=(hx-x*sy)/(hy-x*sx);
			a=sy/n-b*x;
		}
};
int main()
{
	cout<<"hello,world!"<<endl;

	ifstream foo;
	foo.open("a.txt",ios::in);
	if(!foo.is_open())
		return -1;
	std::string str;
	double x=0.0,y=0.0;
	pz z;
	char *m;
	while(getline(foo,str))
	{
		if(str.empty())
			continue;
		m=str.c_str();
		sscanf(m,"%lf %lf",&x,&y);
		free(m);
			z.add(x,y);
		cout<<x<<"\t"<<y<<endl;
	}
	z.show();
	cout<<"y="<<z.a<<"x";
	if(z.b>=0)cout<<"+";
	cout<<z.b<<endl;

	foo.close();
	return 0;
}
