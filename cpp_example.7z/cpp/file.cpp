#include<iostream>
#include<fstream>
#include<cstdlib>
#include<ctime>
using namespace std;

int main()
{
	cout<<"hello,world!"<<endl;

	cout<<"file.cpp"<<endl;
	char buf[1024];
	ofstream fo;// 读 写 读写 ofstream ifstream fstream
	fo.open("a.txt",ios::out|ios::trunc);// 追加(ios::app) 打开后在文件末尾(ios::ate) 用于读(ios::in) 写(ios::out) 从头写(ios::trunc)
	srand((unsigned int)time(NULL));
	for(int i=0;i<10000;i++)fo<<rand()<<endl;
	fo.seekg(5,ios::beg);// 开头 当前 结尾 ios::beg ios::seekp ios::cur
	fo<<"fast"<<endl;
	fo.close();
	return 0;
}
