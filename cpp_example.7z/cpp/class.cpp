#include<iostream>
using namespace std;

class demo{
	int u;//私有
	private://私有

	protected://受保护
	int i;
	public://共有
	static int id;//静态
	virtual void add()
	{
		i++;
	}
	void add2()
	{
		this->add();
		add();
	}
	int geti()
	{
		return i;
	}
	void p()
	{
		cout<<"id:"<<++id<<endl;
	}
	demo()
	{
		cout<<"new"<<endl;
		i=0;
		p();
	}
	demo(int c)
	{
		cout<<"new;i="<<c<<endl;
		i=c;
		p();
	}
	~demo()
	{
		cout<<"close"<<endl;
		i=0;
	}
	demo(const demo &d)
	{
		cout<<"copy;i="<<d.i<<endl;
		i=d.i;
		p();
	}
	friend int getif(demo &d)//不是成员函数 注意类外声明
	{
		return d.i;//protected preate
	}
	demo operator +(const demo& d){
		demo t;
		t.i=this->i+d.i;
		return t;
	}
};
class demox : public demo
{
	public:
		void add3()
		{
			i+=3;
		}
		demox(int c)
		{
			i=c;
		}
		void add()
		{
			cout<<"fake"<<endl;
		}
};
int demo::id=0;
inline void cx(int x)//内联函数
{
	cout<<x<<endl;
}
/* 
 * 访问	public	protected	private
 * 同一个类	yes	yes	yes
 * 派生类	yes	yes	no
 * 外部的类	yes	no	no
 */
class D
{
	public:
		int m;
		void setm(int c)
		{
			m=c;
		}
		int getm()
		{
			return m;
		}
};
class demoD : public demo,public D
{
	public:
		int addx()
		{
			return (i+m);
		}
		demoD(int c)
		{
			i=c;
		}
};
class Pd
{
	public:
		void print(int x)
		{
			cout<<"int:"<<x<<endl;
		}
		void print(float x)
		{
			cout<<"float:"<<x<<endl;
		}
		void print(char x[])
		{
			cout<<"char:"<<x<<endl;
		}
};
class demodx: virtual public demox,virtual public demoD{};
int main()
{
	cout<<"hello,world!"<<endl;
	int i;
	//
	demo d(3);
	for(i=0;i<10;i++)d.add();
	cout<<d.geti()<<endl;
	// 复制
	demo d1(d);
	cout<<d1.geti()<<endl;
	d1.add();
	cout<<getif(d1)<<endl;
	d1.add2();
	// 内联函数
	cx(getif(d1));
	// 指针
	demo *p;
	p=&d1;
	p->add();
	cx(getif(d1));
	// 继承
	demox dx(getif(d1));
	dx.add3();
	cout<<getif(dx)<<endl;
	demoD Dd(5);
	Dd.setm(9);
	cout<<Dd.addx()<<endl;
	//函数重载
	Pd pd;
	pd.print((float)3.14);
	pd.print(5);
	//pd.print("y");
	pd.print(getif(d));
	pd.print(getif(d1));
	//运算符重载
	demo d3=d+d1;
	pd.print(getif(d3));
	//多态
	d.add();
	dx.add();
	//
	return 0;
}
